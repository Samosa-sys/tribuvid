// community.js: logic for community page with real-time updates

let currentUser = null;
let communityId;
let socket;

// Mapping of grades to avatar emoji and highlight colors
const gradeMap = {
  explorateur: { emoji: '🧭', color: 'text-gray-400', ring: '' },
  createur: { emoji: '🎨', color: 'text-blue-400', ring: '' },
  ambassadeur: { emoji: '🤝', color: 'text-purple-400', ring: 'ring ring-purple-400' },
  curateur: { emoji: '👑', color: 'text-yellow-400', ring: 'ring ring-yellow-400' },
  sage: { emoji: '🧠', color: 'text-red-400', ring: 'ring ring-red-400' },
};

function createAvatarSpan(grade) {
  const g = gradeMap[grade.toLowerCase()] || gradeMap.explorateur;
  const span = document.createElement('span');
  span.textContent = g.emoji;
  span.className = `${g.color} mr-1`;
  return span;
}

// Helper: parse query string
function getParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
}

// Ensure user exists and join community for membership and XP
async function initUser() {
  const stored = localStorage.getItem('tribuvid_user');
  if (!stored) {
    alert('Veuillez entrer votre pseudo sur la page d’accueil avant de rejoindre une tribu.');
    window.location = '/';
    return;
  }
  currentUser = JSON.parse(stored);
  // join community to gain membership (and XP)
  await fetch(`/api/communities/${communityId}/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: currentUser.username }),
  });
  // update XP/grade of currentUser by requesting fresh info
  const res = await fetch('/api/auth/ensure-user', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: currentUser.username }),
  });
  const data = await res.json();
  currentUser = data.user;
  localStorage.setItem('tribuvid_user', JSON.stringify(currentUser));
}

function updateSubFormVisibility() {
  const form = document.getElementById('subForm');
  if (!form) return;
  if (currentUser && currentUser.grade.toLowerCase() === 'sage') {
    form.style.display = '';
  } else {
    form.style.display = 'none';
  }
}

async function loadCommunity() {
  const res = await fetch(`/api/communities/${communityId}`);
  if (!res.ok) {
    alert('Communauté introuvable');
    return;
  }
  const data = await res.json();
  renderCommunity(data);
}

function renderCommunity(comm) {
  // header: name, description, members, grade
  const headerDiv = document.getElementById('communityHeader');
  headerDiv.innerHTML = '';
  const title = document.createElement('h1');
  title.className = 'text-2xl font-bold';
  title.textContent = comm.name;
  const desc = document.createElement('p');
  desc.className = 'text-gray-400 mb-2';
  desc.textContent = comm.description || '';
  const members = document.createElement('p');
  members.className = 'text-sm text-gray-500 mb-2';
  members.textContent = `${comm.members} membres`;
  const gradeInfo = document.createElement('p');
  gradeInfo.className = 'text-sm';
  gradeInfo.textContent = currentUser ? `Vous êtes ${currentUser.grade} (XP ${currentUser.xp})` : '';
  headerDiv.appendChild(title);
  headerDiv.appendChild(desc);
  headerDiv.appendChild(members);
  headerDiv.appendChild(gradeInfo);
  // hall of fame
  const hall = document.getElementById('hallOfFame');
  hall.innerHTML = '';
  if (comm.hallOfFame.length === 0) {
    hall.innerHTML = '<p class="text-gray-400">Aucune vidéo en tendance.</p>';
  } else {
    comm.hallOfFame.forEach((v) => {
      const div = createVideoItem(v, true);
      hall.appendChild(div);
    });
  }
  // garbage
  const garbage = document.getElementById('garbage');
  garbage.innerHTML = '';
  if (comm.garbage.length === 0) {
    garbage.innerHTML = '<p class="text-gray-400">Pas encore de vidéos.</p>';
  } else {
    comm.garbage.forEach((v) => {
      const div = createVideoItem(v, false);
      garbage.appendChild(div);
    });
  }
  // posts
  const postsList = document.getElementById('posts');
  postsList.innerHTML = '';
  if (comm.posts.length === 0) {
    postsList.innerHTML = '<p class="text-gray-400">Pas de messages pour l’instant.</p>';
  } else {
    comm.posts.forEach((p) => {
      const item = createPostItem(p);
      postsList.appendChild(item);
    });
  }
  // sub communities
  const sub = document.getElementById('subCommunities');
  sub.innerHTML = '';
  if (comm.subCommunities.length === 0) {
    sub.innerHTML = '<p class="text-gray-400">Aucune sous‑tribu.</p>';
  } else {
    comm.subCommunities.forEach((s) => {
      const card = document.createElement('div');
      card.className = 'bg-gray-800 rounded p-3 shadow';
      card.innerHTML = `
        <h3 class="font-semibold">${s.name}</h3>
        <p class="text-sm text-gray-400 mb-2">${s.description || ''}</p>
        <p class="text-xs text-gray-500 mb-2">${s.members} membres</p>
        <a href="/community.html?id=${s.id}" class="text-indigo-400 hover:underline">Entrer</a>
      `;
      sub.appendChild(card);
    });
  }

  // render polls
  renderPolls(comm.polls || []);
  // render admin actions for sages
  renderAdminActions();
}

// Render list of polls
function renderPolls(polls) {
  const container = document.getElementById('polls');
  container.innerHTML = '';
  if (!polls || polls.length === 0) {
    container.innerHTML = '<p class="text-gray-400">Aucun vote en cours.</p>';
    return;
  }
  polls.forEach((poll) => {
    container.appendChild(createPollItem(poll));
  });
}

// Create a poll element
function createPollItem(poll) {
  const div = document.createElement('div');
  div.className = 'bg-gray-800 p-3 rounded shadow';
  let title;
  if (poll.type === 'delete_community') {
    title = 'Suppression de la tribu';
  } else if (poll.type === 'create_subcommunity') {
    title = `Création de la sous‑tribu “${poll.name}”`;
  } else {
    title = poll.type;
  }
  const header = document.createElement('p');
  header.className = 'font-semibold';
  header.textContent = title;
  div.appendChild(header);
  // counts
  const counts = document.createElement('p');
  counts.className = 'text-sm text-gray-400';
  counts.textContent = `${poll.yes_count} pour • ${poll.no_count} contre`;
  div.appendChild(counts);
  // vote buttons if open
  if (poll.status === 'open' && currentUser) {
    const btns = document.createElement('div');
    btns.className = 'mt-2 flex gap-2';
    const yesBtn = document.createElement('button');
    yesBtn.className = 'bg-green-600 hover:bg-green-700 px-3 py-1 rounded text-sm';
    yesBtn.textContent = 'Pour';
    yesBtn.addEventListener('click', () => {
      votePoll(poll.id, true);
    });
    const noBtn = document.createElement('button');
    noBtn.className = 'bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-sm';
    noBtn.textContent = 'Contre';
    noBtn.addEventListener('click', () => {
      votePoll(poll.id, false);
    });
    btns.appendChild(yesBtn);
    btns.appendChild(noBtn);
    div.appendChild(btns);
  }
  return div;
}

async function votePoll(pollId, voteVal) {
  try {
    await fetch(`/api/polls/${pollId}/votes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, vote: voteVal }),
    });
  } catch (e) {}
}

// Render admin actions (for Sages) to launch new polls
function renderAdminActions() {
  const adminDiv = document.getElementById('adminActions');
  adminDiv.innerHTML = '';
  if (!currentUser || currentUser.grade.toLowerCase() !== 'sage') {
    return;
  }
  // Button to launch deletion poll
  const delBtn = document.createElement('button');
  delBtn.className = 'bg-red-600 hover:bg-red-700 px-4 py-2 rounded mt-2 mr-2';
  delBtn.textContent = 'Lancer un vote pour supprimer la tribu';
  delBtn.addEventListener('click', async () => {
    if (!confirm('Créer un vote pour supprimer cette tribu ?')) return;
    await fetch(`/api/communities/${communityId}/polls`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, type: 'delete_community' }),
    });
  });
  adminDiv.appendChild(delBtn);
  // Button to launch create sub-community poll
  const createPollBtn = document.createElement('button');
  createPollBtn.className = 'bg-green-600 hover:bg-green-700 px-4 py-2 rounded mt-2';
  createPollBtn.textContent = 'Lancer un vote pour créer une sous‑tribu';
  createPollBtn.addEventListener('click', () => {
    const name = prompt('Nom de la nouvelle sous‑tribu :');
    if (!name) return;
    const description = prompt('Description :') || '';
    fetch(`/api/communities/${communityId}/polls`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, type: 'create_subcommunity', name, description }),
    });
  });
  adminDiv.appendChild(createPollBtn);
}

function createVideoItem(v, trending) {
  const div = document.createElement('div');
  div.className = 'bg-gray-800 p-3 rounded shadow flex flex-col';
  div.innerHTML = `
    <h4 class="font-semibold">${v.title}</h4>
    <p class="text-sm text-gray-400">${v.description || ''}</p>
    <p class="text-xs text-gray-500">par ${v.uploader} • ${v.views} vues${trending ? ' • ⭐' : ''}</p>
  `;
  const actions = document.createElement('div');
  actions.className = 'mt-2 flex gap-2';
  const watchBtn = document.createElement('button');
  watchBtn.className = 'bg-indigo-600 hover:bg-indigo-700 px-3 py-1 rounded text-sm';
  watchBtn.textContent = 'Regarder';
  watchBtn.addEventListener('click', () => {
    // open video file in new tab
    window.open(v.file_path, '_blank');
    // record view
    fetch(`/api/videos/${v.id}/view`, { method: 'POST' });
  });
  actions.appendChild(watchBtn);
  // Delete button: visible to uploader or sages
  if (currentUser && (currentUser.username === v.uploader || currentUser.grade.toLowerCase() === 'sage')) {
    const delBtn = document.createElement('button');
    delBtn.className = 'bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-sm';
    delBtn.textContent = 'Supprimer';
    delBtn.addEventListener('click', async () => {
      if (!confirm('Supprimer cette vidéo ?')) return;
      await fetch(`/api/videos/${v.id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: currentUser.username }),
      });
    });
    actions.appendChild(delBtn);
  }
  div.appendChild(actions);
  return div;
}

function createPostItem(p) {
  const div = document.createElement('div');
  const g = gradeMap[p.grade.toLowerCase()] || gradeMap.explorateur;
  // Add highlight ring if applicable
  div.className = `bg-gray-800 p-3 rounded shadow ${g.ring}`;
  const date = new Date(p.created_at);
  // Header line with avatar, username, grade and date
  const header = document.createElement('p');
  header.className = 'text-sm flex items-center';
  // Avatar
  header.appendChild(createAvatarSpan(p.grade));
  // Username
  const userSpan = document.createElement('span');
  userSpan.textContent = p.username;
  userSpan.className = 'font-semibold mr-1';
  header.appendChild(userSpan);
  // Grade text
  const gradeSpan = document.createElement('span');
  gradeSpan.textContent = `(${p.grade})`;
  gradeSpan.className = 'text-xs text-gray-400 mr-1';
  header.appendChild(gradeSpan);
  // Date
  const dateSpan = document.createElement('span');
  dateSpan.textContent = date.toLocaleString();
  dateSpan.className = 'text-xs text-gray-500';
  header.appendChild(document.createTextNode(' • '));
  header.appendChild(dateSpan);
  div.appendChild(header);
  // Content
  const contentPara = document.createElement('p');
  contentPara.className = 'mt-1 text-gray-300';
  contentPara.textContent = p.content;
  div.appendChild(contentPara);
  return div;
}

document.addEventListener('DOMContentLoaded', async () => {
  communityId = getParam('id');
  if (!communityId) {
    alert('Identifiant manquant');
    window.location = '/';
    return;
  }
  await initUser();
  // update user bar
  const userBar = document.getElementById('userBar');
  userBar.innerHTML = `${currentUser.username} <span class="text-xs text-gray-300">(${currentUser.grade}, XP ${currentUser.xp})</span>`;
  // update subForm visibility based on grade
  updateSubFormVisibility();
  socket = io();
  socket.emit('joinCommunityRoom', communityId);
  socket.on('post:new', (post) => {
    const postsList = document.getElementById('posts');
    // prepend new post
    postsList.prepend(createPostItem(post));
  });
  socket.on('video:new', (vid) => {
    // if trending (is_trending==1) may need to update Hall of Fame; else garbage
    if (vid.is_trending) {
      const hall = document.getElementById('hallOfFame');
      hall.prepend(createVideoItem(vid, true));
    } else {
      const garbage = document.getElementById('garbage');
      garbage.prepend(createVideoItem(vid, false));
    }
  });
  socket.on('video:update', (update) => {
    // re-fetch community details to reflect view count/trending changes
    loadCommunity();
  });
  // Poll events
  socket.on('poll:new', (poll) => {
    if (String(poll.community_id) === String(communityId)) {
      const container = document.getElementById('polls');
      // prepend new poll
      container.prepend(createPollItem(poll));
    }
  });
  socket.on('poll:update', (update) => {
    if (String(update.id)) {
      // For simplicity, reload community polls
      loadCommunity();
    }
  });
  socket.on('community:deleted', ({ id }) => {
    if (String(id) === String(communityId)) {
      alert('Cette tribu a été supprimée. Vous allez être redirigé.');
      window.location = '/';
    }
  });
  socket.on('community:new', (comm) => {
    // If a new sub-community is created under this community, reload list
    if (String(comm.parent_id) === String(communityId)) {
      loadCommunity();
    }
  });
  await loadCommunity();
  // handle post form
  document.getElementById('postForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const content = document.getElementById('postContent').value.trim();
    if (!content) return;
    await fetch(`/api/communities/${communityId}/posts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, content }),
    });
    document.getElementById('postContent').value = '';
  });
  // handle sub community form
  document.getElementById('subForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('subName').value.trim();
    const description = document.getElementById('subDesc').value.trim();
    if (!name) return;
    await fetch('/api/communities', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description, parentId: communityId, username: currentUser.username }),
    });
    document.getElementById('subName').value = '';
    document.getElementById('subDesc').value = '';
    loadCommunity();
  });
  // handle video upload form
  document.getElementById('videoForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('videoTitle').value.trim();
    const description = document.getElementById('videoDesc').value.trim();
    const fileInput = document.getElementById('videoFile');
    if (!title || !fileInput.files[0]) return;
    const fd = new FormData();
    fd.append('video', fileInput.files[0]);
    fd.append('title', title);
    fd.append('description', description);
    fd.append('username', currentUser.username);
    const res = await fetch(`/api/communities/${communityId}/videos`, {
      method: 'POST',
      body: fd,
    });
    if (!res.ok) {
      const data = await res.json();
      alert(data.error || 'Erreur lors de l’upload');
    }
    document.getElementById('videoTitle').value = '';
    document.getElementById('videoDesc').value = '';
    document.getElementById('videoFile').value = '';
    // new video will be added via socket event
  });
});