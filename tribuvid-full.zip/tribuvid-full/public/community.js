// community.js: logic for community page with real-time updates

let currentUser = null;
let communityId;
let socket;

// Helper: parse query string
function getParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
}

// Ensure user exists and join community for membership and XP
async function initUser() {
  const stored = localStorage.getItem('tribuvid_user');
  if (!stored) {
    alert('Veuillez entrer votre pseudo sur la page d’accueil avant de rejoindre une tribu.');
    window.location = '/';
    return;
  }
  currentUser = JSON.parse(stored);
  // join community to gain membership (and XP)
  await fetch(`/api/communities/${communityId}/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: currentUser.username }),
  });
  // update XP/grade of currentUser by requesting fresh info
  const res = await fetch('/api/auth/ensure-user', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: currentUser.username }),
  });
  const data = await res.json();
  currentUser = data.user;
  localStorage.setItem('tribuvid_user', JSON.stringify(currentUser));
}

async function loadCommunity() {
  const res = await fetch(`/api/communities/${communityId}`);
  if (!res.ok) {
    alert('Communauté introuvable');
    return;
  }
  const data = await res.json();
  renderCommunity(data);
}

function renderCommunity(comm) {
  // header: name, description, members, grade
  const headerDiv = document.getElementById('communityHeader');
  headerDiv.innerHTML = '';
  const title = document.createElement('h1');
  title.className = 'text-2xl font-bold';
  title.textContent = comm.name;
  const desc = document.createElement('p');
  desc.className = 'text-gray-400 mb-2';
  desc.textContent = comm.description || '';
  const members = document.createElement('p');
  members.className = 'text-sm text-gray-500 mb-2';
  members.textContent = `${comm.members} membres`;
  const gradeInfo = document.createElement('p');
  gradeInfo.className = 'text-sm';
  gradeInfo.textContent = currentUser ? `Vous êtes ${currentUser.grade} (XP ${currentUser.xp})` : '';
  headerDiv.appendChild(title);
  headerDiv.appendChild(desc);
  headerDiv.appendChild(members);
  headerDiv.appendChild(gradeInfo);
  // hall of fame
  const hall = document.getElementById('hallOfFame');
  hall.innerHTML = '';
  if (comm.hallOfFame.length === 0) {
    hall.innerHTML = '<p class="text-gray-400">Aucune vidéo en tendance.</p>';
  } else {
    comm.hallOfFame.forEach((v) => {
      const div = createVideoItem(v, true);
      hall.appendChild(div);
    });
  }
  // garbage
  const garbage = document.getElementById('garbage');
  garbage.innerHTML = '';
  if (comm.garbage.length === 0) {
    garbage.innerHTML = '<p class="text-gray-400">Pas encore de vidéos.</p>';
  } else {
    comm.garbage.forEach((v) => {
      const div = createVideoItem(v, false);
      garbage.appendChild(div);
    });
  }
  // posts
  const postsList = document.getElementById('posts');
  postsList.innerHTML = '';
  if (comm.posts.length === 0) {
    postsList.innerHTML = '<p class="text-gray-400">Pas de messages pour l’instant.</p>';
  } else {
    comm.posts.forEach((p) => {
      const item = createPostItem(p);
      postsList.appendChild(item);
    });
  }
  // sub communities
  const sub = document.getElementById('subCommunities');
  sub.innerHTML = '';
  if (comm.subCommunities.length === 0) {
    sub.innerHTML = '<p class="text-gray-400">Aucune sous‑tribu.</p>';
  } else {
    comm.subCommunities.forEach((s) => {
      const card = document.createElement('div');
      card.className = 'bg-gray-800 rounded p-3 shadow';
      card.innerHTML = `
        <h3 class="font-semibold">${s.name}</h3>
        <p class="text-sm text-gray-400 mb-2">${s.description || ''}</p>
        <p class="text-xs text-gray-500 mb-2">${s.members} membres</p>
        <a href="/community.html?id=${s.id}" class="text-indigo-400 hover:underline">Entrer</a>
      `;
      sub.appendChild(card);
    });
  }
}

function createVideoItem(v, trending) {
  const div = document.createElement('div');
  div.className = 'bg-gray-800 p-3 rounded shadow flex flex-col';
  div.innerHTML = `
    <h4 class="font-semibold">${v.title}</h4>
    <p class="text-sm text-gray-400">${v.description || ''}</p>
    <p class="text-xs text-gray-500">par ${v.uploader} • ${v.views} vues${trending ? ' • ⭐' : ''}</p>
  `;
  const actions = document.createElement('div');
  actions.className = 'mt-2 flex gap-2';
  const watchBtn = document.createElement('button');
  watchBtn.className = 'bg-indigo-600 hover:bg-indigo-700 px-3 py-1 rounded text-sm';
  watchBtn.textContent = 'Regarder';
  watchBtn.addEventListener('click', () => {
    // open video file in new tab
    window.open(v.file_path, '_blank');
    // record view
    fetch(`/api/videos/${v.id}/view`, { method: 'POST' });
  });
  actions.appendChild(watchBtn);
  div.appendChild(actions);
  return div;
}

function createPostItem(p) {
  const div = document.createElement('div');
  div.className = 'bg-gray-800 p-3 rounded shadow';
  const date = new Date(p.created_at);
  div.innerHTML = `
    <p class="text-sm"><span class="font-semibold">${p.username}</span> <span class="text-xs text-gray-400">(${p.grade})</span> • <span class="text-xs text-gray-500">${date.toLocaleString()}</span></p>
    <p class="mt-1 text-gray-300">${p.content}</p>
  `;
  return div;
}

document.addEventListener('DOMContentLoaded', async () => {
  communityId = getParam('id');
  if (!communityId) {
    alert('Identifiant manquant');
    window.location = '/';
    return;
  }
  await initUser();
  // update user bar
  const userBar = document.getElementById('userBar');
  userBar.innerHTML = `${currentUser.username} <span class="text-xs text-gray-300">(${currentUser.grade}, XP ${currentUser.xp})</span>`;
  socket = io();
  socket.emit('joinCommunityRoom', communityId);
  socket.on('post:new', (post) => {
    const postsList = document.getElementById('posts');
    // prepend new post
    postsList.prepend(createPostItem(post));
  });
  socket.on('video:new', (vid) => {
    // if trending (is_trending==1) may need to update Hall of Fame; else garbage
    if (vid.is_trending) {
      const hall = document.getElementById('hallOfFame');
      hall.prepend(createVideoItem(vid, true));
    } else {
      const garbage = document.getElementById('garbage');
      garbage.prepend(createVideoItem(vid, false));
    }
  });
  socket.on('video:update', (update) => {
    // re-fetch community details to reflect view count/trending changes
    loadCommunity();
  });
  await loadCommunity();
  // handle post form
  document.getElementById('postForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const content = document.getElementById('postContent').value.trim();
    if (!content) return;
    await fetch(`/api/communities/${communityId}/posts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, content }),
    });
    document.getElementById('postContent').value = '';
  });
  // handle sub community form
  document.getElementById('subForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('subName').value.trim();
    const description = document.getElementById('subDesc').value.trim();
    if (!name) return;
    await fetch('/api/communities', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description, parentId: communityId }),
    });
    document.getElementById('subName').value = '';
    document.getElementById('subDesc').value = '';
    loadCommunity();
  });
  // handle video upload form
  document.getElementById('videoForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('videoTitle').value.trim();
    const description = document.getElementById('videoDesc').value.trim();
    const fileInput = document.getElementById('videoFile');
    if (!title || !fileInput.files[0]) return;
    const fd = new FormData();
    fd.append('video', fileInput.files[0]);
    fd.append('title', title);
    fd.append('description', description);
    fd.append('username', currentUser.username);
    const res = await fetch(`/api/communities/${communityId}/videos`, {
      method: 'POST',
      body: fd,
    });
    if (!res.ok) {
      const data = await res.json();
      alert(data.error || 'Erreur lors de l’upload');
    }
    document.getElementById('videoTitle').value = '';
    document.getElementById('videoDesc').value = '';
    document.getElementById('videoFile').value = '';
    // new video will be added via socket event
  });
});