// index.js: logic for the home page
let currentUser = null;
let socket = null;

async function ensureUser(username) {
  const res = await fetch('/api/auth/ensure-user', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username }),
  });
  const data = await res.json();
  return data.user;
}

function createCommunityCard(comm) {
  const div = document.createElement('div');
  // Apply custom background color if provided, else default dark gray
  div.className = 'rounded p-4 shadow hover:shadow-lg transition';
  // Set inline background-color to the community color or fallback
  div.style.backgroundColor = comm.color || '#2d3748';
  div.innerHTML = `
    <h3 class="text-lg font-semibold">${comm.name}</h3>
    <p class="text-sm text-gray-300 mb-2">${comm.description || ''}</p>
    <p class="text-xs text-gray-500 mb-2">${comm.members} membres</p>
    <a href="/community.html?id=${comm.id}" class="text-indigo-400 hover:underline">Entrer</a>
  `;
  return div;
}

async function loadCommunities() {
  const res = await fetch('/api/communities');
  const data = await res.json();
  renderCommunities(data);
}

function renderCommunities(list) {
  const container = document.getElementById('communities');
  container.innerHTML = '';
  list.forEach((comm) => {
    container.appendChild(createCommunityCard(comm));
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // Attempt to load saved user
  const stored = localStorage.getItem('tribuvid_user');
  if (stored) {
    currentUser = JSON.parse(stored);
    document.getElementById('username').value = currentUser.username;
    loginInit();
  }
  loadCommunities();
  // search filter
  document.getElementById('search').addEventListener('input', async (e) => {
    const keyword = e.target.value.toLowerCase();
    const res = await fetch('/api/communities');
    const data = await res.json();
    const filtered = data.filter((c) => c.name.toLowerCase().includes(keyword));
    renderCommunities(filtered);
  });
  // login button
  document.getElementById('loginBtn').addEventListener('click', async () => {
    const username = document.getElementById('username').value.trim().toLowerCase();
    if (!username) { alert('Entrez un pseudo'); return; }
    currentUser = await ensureUser(username);
    localStorage.setItem('tribuvid_user', JSON.stringify(currentUser));
    loginInit();
  });
  // create community
  document.getElementById('create-community').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!currentUser) {
      alert('Connectez-vous d’abord');
      return;
    }
    const name = document.getElementById('comm-name').value.trim();
    const description = document.getElementById('comm-desc').value.trim();
    const color = document.getElementById('comm-color')?.value || '#2d3748';
    if (!name) return;
    try {
      const resp = await fetch('/api/communities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description, username: currentUser.username, color }),
      });
      if (!resp.ok) {
        const data = await resp.json();
        if (data && data.error) {
          alert(data.error);
        } else {
          alert('Erreur lors de la création de la tribu');
        }
        return;
      }
      // Clear inputs and reload communities if successful
      document.getElementById('comm-name').value = '';
      document.getElementById('comm-desc').value = '';
      // Reset color picker and preview to default after creation
      const colorPicker = document.getElementById('comm-color');
      const preview = document.getElementById('color-preview');
      if (colorPicker) {
        colorPicker.value = '#2d3748';
        if (preview) preview.style.backgroundColor = '#2d3748';
      }
      loadCommunities();
    } catch (err) {
      console.error(err);
      alert('Erreur réseau lors de la création de la tribu');
    }
  });

  // Live preview update for community color selection
  const colorPicker = document.getElementById('comm-color');
  const colorPreview = document.getElementById('color-preview');
  if (colorPicker && colorPreview) {
    colorPicker.addEventListener('input', (e) => {
      const val = e.target.value;
      colorPreview.style.backgroundColor = val;
    });
  }
});

function loginInit() {
  // Connect socket
  if (!socket) {
    socket = io();
    // When new community is created
    socket.on('community:new', (comm) => {
      loadCommunities();
    });
  }
  document.getElementById('loginBtn').textContent = 'Connecté';
  document.getElementById('loginBtn').disabled = true;
  document.getElementById('username').disabled = true;

  // Show and bind avatar change button
  const avatarBtn = document.getElementById('changeAvatarBtn');
  if (avatarBtn) {
    avatarBtn.classList.remove('hidden');
    // Remove previous listener if any
    avatarBtn.onclick = async () => {
      // Prompt user for new icon (max 2 chars).
      const newIcon = prompt('Choisissez un avatar (1 à 2 caractères ou emoji) :', currentUser.avatar || '');
      if (newIcon === null) return;
      const trimmed = newIcon.trim();
      if (!trimmed) return;
      // Call API to update avatar
      try {
        const resp = await fetch('/api/user/avatar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: currentUser.username, avatar: trimmed }),
        });
        const data = await resp.json();
        if (data.user) {
          currentUser = data.user;
          // Persist to localStorage
          localStorage.setItem('tribuvid_user', JSON.stringify(currentUser));
          alert('Avatar mis à jour !');
        } else if (data.error) {
          alert(data.error);
        }
      } catch (err) {
        console.error(err);
        alert('Erreur lors de la mise à jour de l’avatar');
      }
    };
  }
}