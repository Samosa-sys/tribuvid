// TribuVid server using Express, Socket.IO, better-sqlite3 and Multer
// This server implements the core features described in the concept:
// - Communities and sub-communities with hierarchy
// - Hall of Fame (trending videos) vs garbage lists
// - Forum with real-time updates via Socket.IO
// - Video uploads via Multer
// - Simple gamification (XP and grades)

import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import Database from 'better-sqlite3';
import mime from 'mime';

const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
const PUBLIC_DIR = path.join(process.cwd(), 'public');

// Ensure directories exist
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);
if (!fs.existsSync(PUBLIC_DIR)) fs.mkdirSync(PUBLIC_DIR);

// Initialize SQLite database
const db = new Database('tribuvid.db');

db.exec(`
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS community (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  parent_id INTEGER REFERENCES community(id),
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  grade TEXT NOT NULL DEFAULT 'explorateur',
  xp INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS membership (
  user_id INTEGER NOT NULL REFERENCES user(id),
  community_id INTEGER NOT NULL REFERENCES community(id),
  PRIMARY KEY (user_id, community_id)
);
CREATE TABLE IF NOT EXISTS video (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  community_id INTEGER NOT NULL REFERENCES community(id),
  user_id INTEGER NOT NULL REFERENCES user(id),
  title TEXT NOT NULL,
  description TEXT,
  file_path TEXT NOT NULL,
  views INTEGER NOT NULL DEFAULT 0,
  is_trending INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS post (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  community_id INTEGER NOT NULL REFERENCES community(id),
  user_id INTEGER NOT NULL REFERENCES user(id),
  content TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
`);

// Seed initial data if database empty
const commCount = db.prepare('SELECT COUNT(*) as c FROM community').get().c;
if (commCount === 0) {
  const now = Date.now();
  const insertCommunity = db.prepare('INSERT INTO community(name,slug,description,parent_id,created_at) VALUES (?,?,?,?,?)');
  const sciId = insertCommunity.run('Science', 'science', 'Vidéos et discussions autour de la science', null, now).lastInsertRowid;
  const astroId = insertCommunity.run('Astrophysique', 'astrophysique', 'Une sous‑tribu consacrée à l’astrophysique', sciId, now).lastInsertRowid;
  const insertUser = db.prepare('INSERT INTO user(username,grade,xp,created_at) VALUES (?,?,?,?)');
  const u1 = insertUser.run('alice', 'createur', 120, now).lastInsertRowid;
  const u2 = insertUser.run('bob', 'ambassadeur', 260, now).lastInsertRowid;
  db.prepare('INSERT INTO membership(user_id,community_id) VALUES (?,?)').run(u1, sciId);
  db.prepare('INSERT INTO membership(user_id,community_id) VALUES (?,?)').run(u2, sciId);
  db.prepare('INSERT INTO post(community_id,user_id,content,created_at) VALUES (?,?,?,?)')
    .run(sciId, u1, 'Bienvenue dans la tribu Science ! Partageons nos découvertes.', now);
}

// Helper: compute grade from XP
function computeGrade(xp) {
  if (xp >= 800) return 'sage';
  if (xp >= 500) return 'curateur';
  if (xp >= 300) return 'ambassadeur';
  if (xp >= 150) return 'createur';
  return 'explorateur';
}

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const ext = mime.getExtension(file.mimetype) || path.extname(file.originalname).slice(1) || 'mp4';
    const base = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    cb(null, `${base}.${ext}`);
  },
});
const upload = multer({ storage });

// Middleware for JSON and URL-encoded bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// Serve static files
app.use('/uploads', express.static(UPLOAD_DIR));
app.use('/', express.static(PUBLIC_DIR, { extensions: ['html'] }));

// API: ensure user exists (simple sign-up)
app.post('/api/auth/ensure-user', (req, res) => {
  const { username } = req.body;
  if (!username || !/^[a-z0-9_-]{3,20}$/i.test(username)) {
    return res.status(400).json({ error: 'Nom d’utilisateur invalide' });
  }
  let user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (user) {
    return res.json({ user });
  }
  const now = Date.now();
  const xp = 0;
  const grade = 'explorateur';
  const id = db.prepare('INSERT INTO user(username,grade,xp,created_at) VALUES (?,?,?,?)')
    .run(username, grade, xp, now).lastInsertRowid;
  user = db.prepare('SELECT * FROM user WHERE id=?').get(id);
  res.json({ user });
});

// API: get top-level communities (sorted by membership count)
app.get('/api/communities', (req, res) => {
  const rows = db.prepare(`
    SELECT c.id,c.name,c.slug,c.description,c.parent_id,c.created_at,
           (SELECT COUNT(*) FROM membership m WHERE m.community_id=c.id) as members
    FROM community c
    WHERE parent_id IS NULL
    ORDER BY members DESC, created_at DESC
  `).all();
  res.json(rows);
});

// API: get community details
app.get('/api/communities/:id', (req, res) => {
  const id = Number(req.params.id);
  const comm = db.prepare(`
    SELECT c.id,c.name,c.slug,c.description,c.parent_id,c.created_at,
           (SELECT COUNT(*) FROM membership m WHERE m.community_id=c.id) as members
    FROM community c WHERE id=?
  `).get(id);
  if (!comm) return res.status(404).json({ error: 'Community not found' });
  const children = db.prepare(`
    SELECT id,name,slug,description,parent_id,created_at,
           (SELECT COUNT(*) FROM membership m WHERE m.community_id=community.id) as members
    FROM community WHERE parent_id=? ORDER BY members DESC, created_at DESC
  `).all(id);
  const posts = db.prepare(`
    SELECT p.id,p.content,p.created_at,u.id as user_id,u.username,u.grade
    FROM post p JOIN user u ON p.user_id=u.id
    WHERE p.community_id=? ORDER BY p.created_at DESC LIMIT 100
  `).all(id);
  const videos = db.prepare(`
    SELECT v.id,v.title,v.description,v.file_path,v.views,v.is_trending,v.created_at,
           u.username as uploader
    FROM video v JOIN user u ON v.user_id=u.id
    WHERE v.community_id=?
    ORDER BY v.created_at DESC
  `).all(id);
  const hallOfFame = videos.filter((v) => v.is_trending);
  const garbage = videos.filter((v) => !v.is_trending);
  res.json({
    ...comm,
    subCommunities: children,
    posts,
    hallOfFame,
    garbage,
  });
});

// API: create community or sub-community
app.post('/api/communities', (req, res) => {
  const { name, description, parentId } = req.body;
  if (!name) return res.status(400).json({ error: 'name requis' });
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const now = Date.now();
  const info = db.prepare('INSERT INTO community(name,slug,description,parent_id,created_at) VALUES (?,?,?,?,?)')
    .run(name, slug, description || '', parentId || null, now);
  const comm = db.prepare('SELECT * FROM community WHERE id=?').get(info.lastInsertRowid);
  io.emit('community:new', comm);
  res.json(comm);
});

// API: post in forum
app.post('/api/communities/:id/posts', (req, res) => {
  const id = Number(req.params.id);
  const { username, content } = req.body;
  if (!content || !username) return res.status(400).json({ error: 'contenu/username requis' });
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  const now = Date.now();
  const info = db.prepare('INSERT INTO post(community_id,user_id,content,created_at) VALUES (?,?,?,?)')
    .run(id, user.id, content, now);
  // XP reward for posting
  const newXP = user.xp + 5;
  const newGrade = computeGrade(newXP);
  db.prepare('UPDATE user SET xp=?, grade=? WHERE id=?').run(newXP, newGrade, user.id);
  const postObj = {
    id: info.lastInsertRowid,
    community_id: id,
    user_id: user.id,
    content,
    created_at: now,
    username: user.username,
    grade: newGrade,
  };
  io.to(`comm:${id}`).emit('post:new', postObj);
  res.json({ ok: true, post: postObj });
});

// API: upload video
app.post('/api/communities/:id/videos', upload.single('video'), (req, res) => {
  const id = Number(req.params.id);
  const { username, title, description } = req.body;
  if (!req.file) return res.status(400).json({ error: 'fichier vidéo requis' });
  if (!username || !title) return res.status(400).json({ error: 'username et title requis' });
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  const now = Date.now();
  const info = db.prepare(
    'INSERT INTO video(community_id,user_id,title,description,file_path,views,is_trending,created_at) VALUES (?,?,?,?,?,?,?,?)'
  ).run(id, user.id, title, description || '', `/uploads/${req.file.filename}`, 0, 0, now);
  // XP reward for uploading
  const newXP = user.xp + 15;
  const newGrade = computeGrade(newXP);
  db.prepare('UPDATE user SET xp=?, grade=? WHERE id=?').run(newXP, newGrade, user.id);
  const row = db.prepare(
    'SELECT v.id,v.title,v.description,v.file_path,v.views,v.is_trending,v.created_at,u.username as uploader FROM video v JOIN user u ON v.user_id=u.id WHERE v.id=?'
  ).get(info.lastInsertRowid);
  io.to(`comm:${id}`).emit('video:new', row);
  res.json(row);
});

// API: increment video view count and handle trending
app.post('/api/videos/:id/view', (req, res) => {
  const id = Number(req.params.id);
  const video = db.prepare('SELECT * FROM video WHERE id=?').get(id);
  if (!video) return res.status(404).json({ error: 'video not found' });
  const views = video.views + 1;
  let trending = video.is_trending;
  if (!trending && views >= 25) trending = 1; // trending threshold
  db.prepare('UPDATE video SET views=?, is_trending=? WHERE id=?').run(views, trending, id);
  const updated = db.prepare('SELECT * FROM video WHERE id=?').get(id);
  io.to(`comm:${video.community_id}`).emit('video:update', {
    id: updated.id,
    views: updated.views,
    is_trending: !!updated.is_trending,
  });
  res.json({ ok: true });
});

// API: join community
app.post('/api/communities/:id/join', (req, res) => {
  const id = Number(req.params.id);
  const { username } = req.body;
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  try {
    db.prepare('INSERT INTO membership(user_id,community_id) VALUES (?,?)').run(user.id, id);
  } catch {}
  const newXP = user.xp + 10;
  const newGrade = computeGrade(newXP);
  db.prepare('UPDATE user SET xp=?, grade=? WHERE id=?').run(newXP, newGrade, user.id);
  res.json({ ok: true, grade: newGrade, xp: newXP });
});

// API: leave community
app.post('/api/communities/:id/leave', (req, res) => {
  const id = Number(req.params.id);
  const { username } = req.body;
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  db.prepare('DELETE FROM membership WHERE user_id=? AND community_id=?').run(user.id, id);
  res.json({ ok: true });
});

// Socket.IO: join community room
io.on('connection', (socket) => {
  socket.on('joinCommunityRoom', (communityId) => {
    socket.join(`comm:${communityId}`);
  });
});

// Start server
server.listen(PORT, () => {
  console.log(`TribuVid server started on port ${PORT}`);
});