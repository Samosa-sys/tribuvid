// TribuVid server using Express, Socket.IO, better-sqlite3 and Multer
// This server implements the core features described in the concept:
// - Communities and sub-communities with hierarchy
// - Hall of Fame (trending videos) vs garbage lists
// - Forum with real-time updates via Socket.IO
// - Video uploads via Multer
// - Simple gamification (XP and grades)

import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import Database from 'better-sqlite3';
import mime from 'mime';

const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
const PUBLIC_DIR = path.join(process.cwd(), 'public');

// Ensure directories exist
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);
if (!fs.existsSync(PUBLIC_DIR)) fs.mkdirSync(PUBLIC_DIR);

// Initialize SQLite database
const db = new Database('tribuvid.db');

db.exec(`
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS community (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  parent_id INTEGER REFERENCES community(id),
  creator_id INTEGER REFERENCES user(id),
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  grade TEXT NOT NULL DEFAULT 'explorateur',
  xp INTEGER NOT NULL DEFAULT 0,
  avatar TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS membership (
  user_id INTEGER NOT NULL REFERENCES user(id),
  community_id INTEGER NOT NULL REFERENCES community(id),
  PRIMARY KEY (user_id, community_id)
);
CREATE TABLE IF NOT EXISTS video (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  community_id INTEGER NOT NULL REFERENCES community(id),
  user_id INTEGER NOT NULL REFERENCES user(id),
  title TEXT NOT NULL,
  description TEXT,
  file_path TEXT NOT NULL,
  views INTEGER NOT NULL DEFAULT 0,
  likes INTEGER NOT NULL DEFAULT 0,
  is_trending INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS post (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  community_id INTEGER NOT NULL REFERENCES community(id),
  user_id INTEGER NOT NULL REFERENCES user(id),
  content TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

-- Polls for community moderation and sub-community creation
CREATE TABLE IF NOT EXISTS poll (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  community_id INTEGER NOT NULL REFERENCES community(id),
  type TEXT NOT NULL, -- 'delete_community' or 'create_subcommunity'
  name TEXT,          -- proposed name for sub-community if type=create_subcommunity
  description TEXT,   -- proposed description for sub-community
  yes_count INTEGER NOT NULL DEFAULT 0,
  no_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS poll_vote (
  poll_id INTEGER NOT NULL REFERENCES poll(id),
  user_id INTEGER NOT NULL REFERENCES user(id),
  vote INTEGER NOT NULL, -- 1 for yes, 0 for no
  PRIMARY KEY (poll_id, user_id)
);

-- Track likes per user per video to prevent multiple likes from the same user
CREATE TABLE IF NOT EXISTS video_like (
  video_id INTEGER NOT NULL REFERENCES video(id),
  user_id INTEGER NOT NULL REFERENCES user(id),
  PRIMARY KEY (video_id, user_id)
);
`);

// Ensure avatar column exists on existing databases. If the column already exists, ignore the error.
try {
  db.exec('ALTER TABLE user ADD COLUMN avatar TEXT');
} catch (e) {
  // Column already exists
}

// Ensure likes column exists on existing databases. If the column already exists, ignore the error.
try {
  db.exec('ALTER TABLE video ADD COLUMN likes INTEGER NOT NULL DEFAULT 0');
} catch (e) {
  // Column already exists
}

// Ensure creator_id column exists on community table. This field tracks which user created the community.
try {
  db.exec('ALTER TABLE community ADD COLUMN creator_id INTEGER');
} catch (e) {
  // Column already exists
}

// Seed initial data if database empty
const commCount = db.prepare('SELECT COUNT(*) as c FROM community').get().c;
if (commCount === 0) {
  const now = Date.now();
  const insertCommunity = db.prepare('INSERT INTO community(name,slug,description,parent_id,created_at) VALUES (?,?,?,?,?)');
  const sciId = insertCommunity.run('Science', 'science', 'Vidéos et discussions autour de la science', null, now).lastInsertRowid;
  const astroId = insertCommunity.run('Astrophysique', 'astrophysique', 'Une sous‑tribu consacrée à l’astrophysique', sciId, now).lastInsertRowid;
  const insertUser = db.prepare('INSERT INTO user(username,grade,xp,created_at) VALUES (?,?,?,?)');
  const u1 = insertUser.run('alice', 'createur', 120, now).lastInsertRowid;
  const u2 = insertUser.run('bob', 'ambassadeur', 260, now).lastInsertRowid;
  db.prepare('INSERT INTO membership(user_id,community_id) VALUES (?,?)').run(u1, sciId);
  db.prepare('INSERT INTO membership(user_id,community_id) VALUES (?,?)').run(u2, sciId);
  db.prepare('INSERT INTO post(community_id,user_id,content,created_at) VALUES (?,?,?,?)')
    .run(sciId, u1, 'Bienvenue dans la tribu Science ! Partageons nos découvertes.', now);
}

// Helper: compute grade from XP
function computeGrade(xp) {
  if (xp >= 800) return 'sage';
  if (xp >= 500) return 'curateur';
  if (xp >= 300) return 'ambassadeur';
  if (xp >= 150) return 'createur';
  return 'explorateur';
}

// Helper: recursively delete a community and all its related data (videos, posts, polls, votes, membership, sub-communities)
function deleteCommunityRecursive(commId) {
  // Delete videos and their files
  const vids = db.prepare('SELECT id,file_path FROM video WHERE community_id=?').all(commId);
  vids.forEach((v) => {
    const filePath = path.join(process.cwd(), v.file_path.replace(/^\//, ''));
    try {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    } catch {}
  });
  db.prepare('DELETE FROM video WHERE community_id=?').run(commId);
  // Delete posts
  db.prepare('DELETE FROM post WHERE community_id=?').run(commId);
  // Delete poll votes and polls
  const polls = db.prepare('SELECT id FROM poll WHERE community_id=?').all(commId);
  polls.forEach((p) => {
    db.prepare('DELETE FROM poll_vote WHERE poll_id=?').run(p.id);
  });
  db.prepare('DELETE FROM poll WHERE community_id=?').run(commId);
  // Delete memberships
  db.prepare('DELETE FROM membership WHERE community_id=?').run(commId);
  // Recursively delete sub-communities
  const subs = db.prepare('SELECT id FROM community WHERE parent_id=?').all(commId);
  subs.forEach((sc) => deleteCommunityRecursive(sc.id));
  // Finally delete community
  db.prepare('DELETE FROM community WHERE id=?').run(commId);
}

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const ext = mime.getExtension(file.mimetype) || path.extname(file.originalname).slice(1) || 'mp4';
    const base = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    cb(null, `${base}.${ext}`);
  },
});
const upload = multer({ storage });

// Middleware for JSON and URL-encoded bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// Serve static files
app.use('/uploads', express.static(UPLOAD_DIR));
// NOTE: We deliberately mount the static public directory **after** all API routes
// (see bottom of file) to ensure that '/api/...'
// paths are not intercepted by the static middleware. Mounting early would
// cause API endpoints like '/api/communities/:id' to fall through to the
// static file server, resulting in 404 responses and the “Communauté
// introuvable” error observed on the front-end.


// API: ensure user exists (simple sign-up)
app.post('/api/auth/ensure-user', (req, res) => {
  const { username } = req.body;
  if (!username || !/^[a-z0-9_-]{3,20}$/i.test(username)) {
    return res.status(400).json({ error: 'Nom d’utilisateur invalide' });
  }
  let user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (user) {
    return res.json({ user });
  }
  const now = Date.now();
  const xp = 0;
  const grade = 'explorateur';
  const id = db.prepare('INSERT INTO user(username,grade,xp,created_at) VALUES (?,?,?,?)')
    .run(username, grade, xp, now).lastInsertRowid;
  user = db.prepare('SELECT * FROM user WHERE id=?').get(id);
  res.json({ user });
});

// API: get top-level communities (sorted by membership count)
app.get('/api/communities', (req, res) => {
  const rows = db.prepare(`
    SELECT c.id,c.name,c.slug,c.description,c.parent_id,c.created_at,
           (SELECT COUNT(*) FROM membership m WHERE m.community_id=c.id) as members
    FROM community c
    WHERE parent_id IS NULL
    ORDER BY members DESC, created_at DESC
  `).all();
  res.json(rows);
});

// API: get community details.
// Accepts a numeric ID or a slug. If the parameter is all digits, it is treated as an ID.
// Otherwise, the community is looked up by its slug. This prevents "Community not found" errors
// when using slugs in URLs.
app.get('/api/communities/:id', (req, res) => {
  const idParam = req.params.id;
  let comm;
  // Determine whether the parameter is a numeric ID (digits only).
  if (/^\d+$/.test(idParam)) {
    const idNum = Number(idParam);
    comm = db.prepare(
      `SELECT c.id,c.name,c.slug,c.description,c.parent_id,c.created_at,
              (SELECT COUNT(*) FROM membership m WHERE m.community_id=c.id) as members
       FROM community c WHERE id=?`
    ).get(idNum);
  } else {
    // Look up by slug
    comm = db.prepare(
      `SELECT c.id,c.name,c.slug,c.description,c.parent_id,c.created_at,
              (SELECT COUNT(*) FROM membership m WHERE m.community_id=c.id) as members
       FROM community c WHERE slug=?`
    ).get(idParam);
  }
  if (!comm) return res.status(404).json({ error: 'Community not found' });
  // Use the resolved numeric ID from the community record for the remainder of queries
  const cid = comm.id;
  const children = db.prepare(
    `SELECT id,name,slug,description,parent_id,created_at,
            (SELECT COUNT(*) FROM membership m WHERE m.community_id=community.id) as members
     FROM community WHERE parent_id=? ORDER BY members DESC, created_at DESC`
  ).all(cid);
  const posts = db.prepare(
    `SELECT p.id,p.content,p.created_at,u.id as user_id,u.username,u.grade,u.avatar
     FROM post p JOIN user u ON p.user_id=u.id
     WHERE p.community_id=? ORDER BY p.created_at DESC LIMIT 100`
  ).all(cid);
  const videos = db.prepare(
    `SELECT v.id,v.title,v.description,v.file_path,v.views,v.likes,v.is_trending,v.created_at,
            u.username as uploader
     FROM video v JOIN user u ON v.user_id=u.id
     WHERE v.community_id=?
     ORDER BY v.created_at DESC`
  ).all(cid);
  const hallOfFame = videos.filter((v) => v.is_trending);
  const garbage = videos.filter((v) => !v.is_trending);
  // fetch open polls for this community
  // Use single quotes around the string literal "open" to avoid SQLite interpreting it as a column name
  const polls = db.prepare('SELECT * FROM poll WHERE community_id=? AND status=\'open\'').all(cid);
  res.json({
    ...comm,
    subCommunities: children,
    posts,
    hallOfFame,
    garbage,
    polls,
  });
});

// API: create community or sub-community
app.post('/api/communities', (req, res) => {
  const { name, description, parentId, username } = req.body;
  if (!name) return res.status(400).json({ error: 'name requis' });
  if (!username) return res.status(400).json({ error: 'username requis' });
  // Disallow direct creation of sub-communities; must go through vote
  if (parentId) {
    return res.status(403).json({ error: 'La création de sous-communautés nécessite un vote de la communauté. Veuillez lancer un vote via le forum.' });
  }
  // Retrieve user info
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) {
    return res.status(400).json({ error: 'utilisateur inconnu' });
  }
  const userGrade = (user.grade || '').toLowerCase();
  // Non-sages are limited to one community created (top level)
  if (userGrade !== 'sage') {
    const existingCount = db.prepare('SELECT COUNT(*) as c FROM community WHERE creator_id=? AND parent_id IS NULL').get(user.id).c;
    if (existingCount >= 1) {
      return res.status(403).json({ error: 'Vous avez déjà créé une tribu. Seuls les Sages peuvent en créer plusieurs.' });
    }
  }
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const now = Date.now();
  // Insert community with creator_id
  const info = db.prepare(
    'INSERT INTO community(name,slug,description,parent_id,creator_id,created_at) VALUES (?,?,?,?,?,?)'
  ).run(name, slug, description || '', parentId || null, user.id, now);
  const comm = db.prepare('SELECT * FROM community WHERE id=?').get(info.lastInsertRowid);
  io.emit('community:new', comm);
  res.json(comm);
});

// API: post in forum
app.post('/api/communities/:id/posts', (req, res) => {
  const id = Number(req.params.id);
  const { username, content } = req.body;
  if (!content || !username) return res.status(400).json({ error: 'contenu/username requis' });
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  const now = Date.now();
  const info = db.prepare('INSERT INTO post(community_id,user_id,content,created_at) VALUES (?,?,?,?)')
    .run(id, user.id, content, now);
  // XP reward for posting
  const newXP = user.xp + 5;
  const newGrade = computeGrade(newXP);
  db.prepare('UPDATE user SET xp=?, grade=? WHERE id=?').run(newXP, newGrade, user.id);
  const postObj = {
    id: info.lastInsertRowid,
    community_id: id,
    user_id: user.id,
    content,
    created_at: now,
    username: user.username,
    grade: newGrade,
    avatar: user.avatar || null,
  };
  io.to(`comm:${id}`).emit('post:new', postObj);
  res.json({ ok: true, post: postObj });
});

// API: upload video
app.post('/api/communities/:id/videos', upload.single('video'), (req, res) => {
  const id = Number(req.params.id);
  const { username, title, description } = req.body;
  if (!req.file) return res.status(400).json({ error: 'fichier vidéo requis' });
  if (!username || !title) return res.status(400).json({ error: 'username et title requis' });
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  const now = Date.now();
  // Check if user has already uploaded a video within the last 24 hours across all communities
  const twentyFourHoursAgo = now - 24 * 60 * 60 * 1000;
  const recentUpload = db.prepare('SELECT COUNT(*) as c FROM video WHERE user_id=? AND created_at>?').get(user.id, twentyFourHoursAgo).c;
  if (recentUpload > 0) {
    return res.status(403).json({ error: 'Vous avez déjà posté une vidéo aujourd’hui. Veuillez attendre avant d’en publier une nouvelle.' });
  }
  const info = db.prepare(
    'INSERT INTO video(community_id,user_id,title,description,file_path,views,likes,is_trending,created_at) VALUES (?,?,?,?,?,?,?,?,?)'
  ).run(id, user.id, title, description || '', `/uploads/${req.file.filename}`, 0, 0, 0, now);
  // XP reward for uploading
  const newXP = user.xp + 15;
  const newGrade = computeGrade(newXP);
  db.prepare('UPDATE user SET xp=?, grade=? WHERE id=?').run(newXP, newGrade, user.id);
  const row = db.prepare(
    'SELECT v.id,v.title,v.description,v.file_path,v.views,v.likes,v.is_trending,v.created_at,u.username as uploader FROM video v JOIN user u ON v.user_id=u.id WHERE v.id=?'
  ).get(info.lastInsertRowid);
  io.to(`comm:${id}`).emit('video:new', row);
  res.json(row);
});

// API: increment video view count and handle trending
app.post('/api/videos/:id/view', (req, res) => {
  const id = Number(req.params.id);
  const video = db.prepare('SELECT * FROM video WHERE id=?').get(id);
  if (!video) return res.status(404).json({ error: 'video not found' });
  // Increment view count
  const views = video.views + 1;
  // compute points based on views and likes (views = 1 point, likes = 5 points)
  const likes = video.likes;
  const points = views + likes * 5;
  // Determine if should become trending
  let trending = video.is_trending;
  if (!trending && points >= 150) {
    trending = 1;
  }
  db.prepare('UPDATE video SET views=?, is_trending=? WHERE id=?').run(views, trending, id);
  const updated = db.prepare('SELECT * FROM video WHERE id=?').get(id);
  io.to(`comm:${video.community_id}`).emit('video:update', {
    id: updated.id,
    views: updated.views,
    likes: updated.likes,
    is_trending: !!updated.is_trending,
  });
  res.json({ ok: true });
});

// API: delete a video
// A video can be deleted either by its uploader or by a user with the 'sage' grade.
app.delete('/api/videos/:id', (req, res) => {
  const id = Number(req.params.id);
  const { username } = req.body;
  if (!username) return res.status(400).json({ error: 'username requis' });
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  const video = db.prepare('SELECT * FROM video WHERE id=?').get(id);
  if (!video) return res.status(404).json({ error: 'video introuvable' });
  // Check permissions: uploader or sage can delete
  if (user.id !== video.user_id && user.grade.toLowerCase() !== 'sage') {
    return res.status(403).json({ error: 'Accès refusé (vous n\'êtes pas propriétaire ni Sage)' });
  }
  // Remove video file from disk if present
  try {
    const filepath = path.join(process.cwd(), video.file_path.replace(/^\//, ''));
    if (fs.existsSync(filepath)) {
      fs.unlinkSync(filepath);
    }
  } catch {}
  // Delete from database
  db.prepare('DELETE FROM video WHERE id=?').run(id);
  // Notify clients in community room
  io.to(`comm:${video.community_id}`).emit('video:deleted', { id });
  res.json({ ok: true });
});

// API: join community
app.post('/api/communities/:id/join', (req, res) => {
  const id = Number(req.params.id);
  const { username } = req.body;
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  try {
    db.prepare('INSERT INTO membership(user_id,community_id) VALUES (?,?)').run(user.id, id);
  } catch {}
  const newXP = user.xp + 10;
  const newGrade = computeGrade(newXP);
  db.prepare('UPDATE user SET xp=?, grade=? WHERE id=?').run(newXP, newGrade, user.id);
  res.json({ ok: true, grade: newGrade, xp: newXP });
});

// API: leave community
app.post('/api/communities/:id/leave', (req, res) => {
  const id = Number(req.params.id);
  const { username } = req.body;
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  db.prepare('DELETE FROM membership WHERE user_id=? AND community_id=?').run(user.id, id);
  res.json({ ok: true });
});

// API: update a user's avatar. Allows a logged-in user to change their avatar icon.
// Expects JSON body with { username, avatar }. Returns updated user data.
app.post('/api/user/avatar', (req, res) => {
  const { username, avatar } = req.body;
  if (!username || typeof avatar !== 'string') {
    return res.status(400).json({ error: 'username et avatar requis' });
  }
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  // Trim avatar to at most two Unicode characters to avoid long strings or injections
  const trimmed = avatar.trim().slice(0, 2);
  db.prepare('UPDATE user SET avatar=? WHERE id=?').run(trimmed, user.id);
  const updated = db.prepare('SELECT * FROM user WHERE id=?').get(user.id);
  res.json({ ok: true, user: updated });
});

// API: create a poll for community moderation
// Only Sages can initiate polls. Types: 'delete_community' or 'create_subcommunity'.
app.post('/api/communities/:id/polls', (req, res) => {
  const id = Number(req.params.id);
  const { username, type, name, description } = req.body;
  if (!username || !type) return res.status(400).json({ error: 'username et type requis' });
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  // Only ambassadors or higher (ambassadeur, curateur, sage) can initiate polls
  const grade = user.grade.toLowerCase();
  if (!['ambassadeur', 'curateur', 'sage'].includes(grade)) {
    return res.status(403).json({ error: 'Seuls les ambassadeurs, curateurs ou sages peuvent créer un vote de modération' });
  }
  if (type !== 'delete_community' && type !== 'create_subcommunity') {
    return res.status(400).json({ error: 'Type de vote invalide' });
  }
  // For create_subcommunity, name is required
  if (type === 'create_subcommunity' && !name) {
    return res.status(400).json({ error: 'Le nom de la sous-communauté est requis pour ce vote' });
  }
  const now = Date.now();
  const insertPoll = db.prepare('INSERT INTO poll(community_id,type,name,description,yes_count,no_count,status,created_at) VALUES (?,?,?,?,?,?,?,?)');
  const pollId = insertPoll.run(id, type, name || null, description || null, 0, 0, 'open', now).lastInsertRowid;
  const poll = db.prepare('SELECT * FROM poll WHERE id=?').get(pollId);
  // Broadcast new poll to community
  io.to(`comm:${id}`).emit('poll:new', poll);
  res.json(poll);
});

// API: vote on a poll (yes/no)
app.post('/api/polls/:pollId/votes', (req, res) => {
  const pollId = Number(req.params.pollId);
  const { username, vote } = req.body;
  if (typeof vote === 'undefined' || !username) {
    return res.status(400).json({ error: 'username et vote requis' });
  }
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  const poll = db.prepare('SELECT * FROM poll WHERE id=?').get(pollId);
  if (!poll) return res.status(404).json({ error: 'Vote introuvable' });
  if (poll.status !== 'open') return res.status(400).json({ error: 'Ce vote est fermé' });
  // Convert vote to boolean integer (1 for yes, 0 for no)
  const val = typeof vote === 'string' ? (vote.toLowerCase() === 'yes' || vote === '1' ? 1 : 0) : (vote ? 1 : 0);
  // Check if user already voted
  const existing = db.prepare('SELECT * FROM poll_vote WHERE poll_id=? AND user_id=?').get(pollId, user.id);
  if (existing) return res.status(400).json({ error: 'Vous avez déjà voté' });
  // Insert vote
  db.prepare('INSERT INTO poll_vote(poll_id,user_id,vote) VALUES (?,?,?)').run(pollId, user.id, val);
  // Update counts
  let yesCount = poll.yes_count;
  let noCount = poll.no_count;
  if (val === 1) yesCount++;
  else noCount++;
  db.prepare('UPDATE poll SET yes_count=?, no_count=? WHERE id=?').run(yesCount, noCount, pollId);
  // Re-fetch poll
  const updatedPoll = db.prepare('SELECT * FROM poll WHERE id=?').get(pollId);
  // Check if difference reaches threshold
  const diff = Math.abs(updatedPoll.yes_count - updatedPoll.no_count);
  let finalised = false;
  if (diff >= 10) {
    // Close poll
    db.prepare('UPDATE poll SET status=? WHERE id=?').run('closed', pollId);
    finalised = true;
    // Perform action depending on poll type
    if (updatedPoll.type === 'delete_community') {
      // Delete community recursively
      deleteCommunityRecursive(updatedPoll.community_id);
      // Notify all clients to refresh communities list
      io.emit('community:deleted', { id: updatedPoll.community_id });
    } else if (updatedPoll.type === 'create_subcommunity') {
      // Create new sub-community under the same community
      const name = updatedPoll.name;
      const description = updatedPoll.description || '';
      const parentId = updatedPoll.community_id;
      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const now = Date.now();
      const newId = db.prepare(
        'INSERT INTO community(name,slug,description,parent_id,created_at) VALUES (?,?,?,?,?)'
      ).run(name, slug, description, parentId, now).lastInsertRowid;
      const newComm = db.prepare('SELECT * FROM community WHERE id=?').get(newId);
      io.emit('community:new', newComm);
    }
  }
  // Emit poll update to community
  io.to(`comm:${poll.community_id}`).emit('poll:update', {
    id: updatedPoll.id,
    yes_count: yesCount,
    no_count: noCount,
    status: finalised ? 'closed' : 'open',
  });
  res.json({ ok: true, poll: { ...updatedPoll, yes_count: yesCount, no_count: noCount, status: finalised ? 'closed' : 'open' } });
});

// API: like a video. A user can like a video once; likes contribute to trending points (5 points each).
app.post('/api/videos/:id/like', (req, res) => {
  const id = Number(req.params.id);
  const { username } = req.body;
  if (!username) return res.status(400).json({ error: 'username requis' });
  const user = db.prepare('SELECT * FROM user WHERE username=?').get(username);
  if (!user) return res.status(400).json({ error: 'user inconnu' });
  const video = db.prepare('SELECT * FROM video WHERE id=?').get(id);
  if (!video) return res.status(404).json({ error: 'vidéo introuvable' });
  // Check if user already liked this video
  const existing = db.prepare('SELECT 1 FROM video_like WHERE video_id=? AND user_id=?').get(id, user.id);
  if (existing) {
    return res.status(400).json({ error: 'Vous avez déjà liké cette vidéo' });
  }
  // Insert like record
  db.prepare('INSERT INTO video_like(video_id,user_id) VALUES (?,?)').run(id, user.id);
  // Increment like count on video
  const newLikes = video.likes + 1;
  // Compute points to determine trending
  const views = video.views;
  const points = views + newLikes * 5;
  let trending = video.is_trending;
  if (!trending && points >= 150) trending = 1;
  db.prepare('UPDATE video SET likes=?, is_trending=? WHERE id=?').run(newLikes, trending, id);
  // Optionally award XP to liker and uploader
  // Award 2 XP to liker
  const likerXP = user.xp + 2;
  const likerGrade = computeGrade(likerXP);
  db.prepare('UPDATE user SET xp=?, grade=? WHERE id=?').run(likerXP, likerGrade, user.id);
  // Award 5 XP to video uploader if liked by someone else
  if (user.id !== video.user_id) {
    const uploader = db.prepare('SELECT * FROM user WHERE id=?').get(video.user_id);
    if (uploader) {
      const uploaderXP = uploader.xp + 5;
      const uploaderGrade = computeGrade(uploaderXP);
      db.prepare('UPDATE user SET xp=?, grade=? WHERE id=?').run(uploaderXP, uploaderGrade, uploader.id);
    }
  }
  // Broadcast update
  const updated = db.prepare('SELECT * FROM video WHERE id=?').get(id);
  io.to(`comm:${video.community_id}`).emit('video:update', {
    id: updated.id,
    views: updated.views,
    likes: updated.likes,
    is_trending: !!updated.is_trending,
  });
  res.json({ ok: true, likes: updated.likes, is_trending: !!updated.is_trending });
});

// Static definitions of grade advantages. This object maps each grade to a list of advantages.
const gradeAdvantages = {
  explorateur: [
    'Publier des vidéos dans le vide‑grenier',
    'Participer aux discussions sur l’Agora',
    'Voter dans les sondages communautaires',
  ],
  createur: [
    'Tout ce qu’un Explorateur peut faire',
    'Proposer ses propres vidéos au Palmarès (Hall of Fame) lorsqu’elles atteignent le seuil',
    'Recevoir des badges et décorations',
  ],
  ambassadeur: [
    'Tout ce qu’un Créateur peut faire',
    'Mise en avant automatique de ses vidéos dans l’Agora',
    'Lancer des votes pour créer ou supprimer des tribus ou sous‑tribus',
    'Parrainer des sous‑tribus',
    'Messages surlignés et avatar spécial',
  ],
  curateur: [
    'Tout ce qu’un Ambassadeur peut faire',
    'Sélectionner les vidéos qui montent du Vide‑grenier au Palmarès',
    'Modérer les discussions et fusionner des sous‑tribus',
    'Accès à des statistiques avancées',
  ],
  sage: [
    'Tout ce qu’un Curateur peut faire',
    'Supprimer ou fusionner des communautés entières',
    'Gérer les votes communautaires et arbitrer en dernier recours',
    'Créer des événements et annonces pour l’ensemble de la plateforme',
  ],
};

// API: return the list of advantages for each grade
app.get('/api/grade-advantages', (req, res) => {
  res.json(gradeAdvantages);
});

// Mount static public directory after all API routes. By placing this here, we avoid
// Express.static intercepting API paths (e.g. '/api/communities/...') which would
// otherwise return 404 and cause the "Communauté introuvable" error. Any
// unmatched route will fall back to serving files from the public folder.
app.use('/', express.static(PUBLIC_DIR, { extensions: ['html'] }));

// Socket.IO: join community room
io.on('connection', (socket) => {
  socket.on('joinCommunityRoom', (communityId) => {
    socket.join(`comm:${communityId}`);
  });
});

// Start server
server.listen(PORT, () => {
  console.log(`TribuVid server started on port ${PORT}`);
});