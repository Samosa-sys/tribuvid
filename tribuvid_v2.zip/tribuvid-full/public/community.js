// community.js: logic for community page with real-time updates

let currentUser = null;
let communityId;
let socket;

// Mapping of grades to avatar emoji and highlight colors
const gradeMap = {
  explorateur: { emoji: '🧭', color: 'text-gray-400', ring: '' },
  createur: { emoji: '🎨', color: 'text-blue-400', ring: '' },
  ambassadeur: { emoji: '🤝', color: 'text-purple-400', ring: 'ring ring-purple-400' },
  curateur: { emoji: '👑', color: 'text-yellow-400', ring: 'ring ring-yellow-400' },
  sage: { emoji: '🧠', color: 'text-red-400', ring: 'ring ring-red-400' },
};

// Reaction types available on videos and posts. Each entry contains the emoji
// displayed to the user and the identifier sent to the API. Additional reaction
// types can be appended here without touching the rest of the UI logic.
const reactionTypes = [
  { emoji: '🔥', type: 'fire' },
  { emoji: '❤️', type: 'heart' },
  { emoji: '💡', type: 'idea' },
  { emoji: '👎', type: 'thumbs_down' },
];

// Display a floating notification at the bottom of the screen. Useful for
// signalling XP gains or other status messages. The toast automatically
// disappears after a few seconds.
function showToast(message) {
  const toast = document.createElement('div');
  toast.textContent = message;
  toast.className =
    'fixed bottom-4 right-4 bg-indigo-600 text-white px-4 py-2 rounded shadow-lg z-50';
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('opacity-0');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Render the user bar at the top of the page. Displays the user avatar, name,
// grade, XP bar and earned badges. This should be called whenever currentUser
// changes or when the page is initialised.
function renderUserBar() {
  const bar = document.getElementById('userBar');
  if (!bar || !currentUser) return;
  bar.innerHTML = '';
  // avatar icon according to grade or custom avatar
  bar.appendChild(createAvatarSpan(currentUser.grade, currentUser.avatar));
  // username and grade
  const info = document.createElement('span');
  info.className = 'mr-2 font-semibold';
  info.textContent = `${currentUser.username} (${currentUser.grade})`;
  bar.appendChild(info);
  // XP progress bar (simplified). Assume each level requires 100 XP.
  const xpContainer = document.createElement('div');
  xpContainer.className = 'flex items-center mr-2';
  const barOuter = document.createElement('div');
  barOuter.className = 'w-40 h-2 bg-gray-700 rounded overflow-hidden';
  const barInner = document.createElement('div');
  const progress = Math.min((currentUser.xp % 100) / 100 * 100, 100);
  barInner.style.width = progress + '%';
  barInner.className = 'h-2 bg-green-500';
  barOuter.appendChild(barInner);
  xpContainer.appendChild(barOuter);
  const xpLabel = document.createElement('span');
  xpLabel.className = 'text-xs text-gray-400 ml-1';
  xpLabel.textContent = `${currentUser.xp} XP`;
  xpContainer.appendChild(xpLabel);
  bar.appendChild(xpContainer);
  // badges display (simple icons). Expect currentUser.badges as an array of strings.
  if (currentUser.badges && currentUser.badges.length > 0) {
    const badgesDiv = document.createElement('div');
    badgesDiv.className = 'flex gap-1';
    currentUser.badges.forEach((b) => {
      const badgeSpan = document.createElement('span');
      badgeSpan.className = 'text-yellow-300';
      badgeSpan.textContent = b;
      badgesDiv.appendChild(badgeSpan);
    });
    bar.appendChild(badgesDiv);
  }
}

// Compute and render the weekly ranking of videos and members. The ranking is
// based on the number of views and likes a video has accumulated over the
// current week. This function assumes the community object contains a
// `hallOfFame` and `garbage` array of video objects. Each video can have
// properties `views` and `likes`. Top members ranking is based on XP.
function renderWeeklyRanking(comm) {
  const container = document.getElementById('weeklyRanking');
  if (!container) return;
  container.innerHTML = '';
  // Collect all videos from hallOfFame and garbage arrays
  const allVideos = [];
  if (Array.isArray(comm.hallOfFame)) allVideos.push(...comm.hallOfFame);
  if (Array.isArray(comm.garbage)) allVideos.push(...comm.garbage);
  if (allVideos.length === 0) {
    container.innerHTML = '<p class="text-gray-400">Pas encore de vidéos pour le classement.</p>';
    return;
  }
  // Sort videos by points (views + 5*likes) descending
  const scored = allVideos.map((v) => {
    const likes = typeof v.likes === 'number' ? v.likes : 0;
    const points = (v.views || 0) + likes * 5;
    return { ...v, points };
  });
  scored.sort((a, b) => b.points - a.points);
  // Build top videos list
  const topSection = document.createElement('div');
  const topTitle = document.createElement('h4');
  topTitle.className = 'font-semibold';
  topTitle.textContent = 'Top vidéos';
  topSection.appendChild(topTitle);
  scored.slice(0, 5).forEach((v, idx) => {
    const item = document.createElement('p');
    item.className = 'text-sm text-gray-300';
    item.textContent = `${idx + 1}. ${v.title} – ${v.points} pts`;
    topSection.appendChild(item);
  });
  container.appendChild(topSection);
  // Top members by XP (requires comm.membersStats or we use currentUser only)
  if (comm.memberStats && Array.isArray(comm.memberStats)) {
    const sortedMembers = [...comm.memberStats].sort((a, b) => (b.xp || 0) - (a.xp || 0));
    const memSection = document.createElement('div');
    memSection.className = 'mt-4';
    const memTitle = document.createElement('h4');
    memTitle.className = 'font-semibold';
    memTitle.textContent = 'Membres les plus actifs';
    memSection.appendChild(memTitle);
    sortedMembers.slice(0, 5).forEach((m, idx) => {
      const item = document.createElement('p');
      item.className = 'text-sm text-gray-300';
      item.textContent = `${idx + 1}. ${m.username} – ${m.xp} XP`;
      memSection.appendChild(item);
    });
    container.appendChild(memSection);
  }
}

// Create an avatar span. If a custom icon is provided (two characters or an emoji),
// it will be used instead of the default grade-based emoji. The color of the icon
// still reflects the user's grade.
function createAvatarSpan(grade, customIcon) {
  const g = gradeMap[grade.toLowerCase()] || gradeMap.explorateur;
  const span = document.createElement('span');
  // Use customIcon if defined and non-empty; otherwise fallback to the grade emoji
  const icon = (customIcon && customIcon.trim() !== '') ? customIcon : g.emoji;
  span.textContent = icon;
  span.className = `${g.color} mr-1`;
  return span;
}

// Helper: parse query string
function getParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
}

// Ensure user exists and join community for membership and XP
async function initUser() {
  const stored = localStorage.getItem('tribuvid_user');
  if (!stored) {
    alert('Veuillez entrer votre pseudo sur la page d’accueil avant de rejoindre une tribu.');
    window.location = '/';
    return;
  }
  currentUser = JSON.parse(stored);
  // join community to gain membership (and XP)
  await fetch(`/api/communities/${communityId}/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: currentUser.username }),
  });
  // update XP/grade of currentUser by requesting fresh info
  const res = await fetch('/api/auth/ensure-user', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: currentUser.username }),
  });
  const data = await res.json();
  currentUser = data.user;
  localStorage.setItem('tribuvid_user', JSON.stringify(currentUser));

  // Refresh user bar after updating user info
  renderUserBar();
}

function updateSubFormVisibility() {
  const form = document.getElementById('subForm');
  if (!form) return;
  // Disable direct creation of sub-tribes: always hide the form. Creation is handled via polls.
  form.style.display = 'none';
}

async function loadCommunity() {
  const res = await fetch(`/api/communities/${communityId}`);
  if (!res.ok) {
    alert('Communauté introuvable');
    return;
  }
  const data = await res.json();
  renderCommunity(data);
}

function renderCommunity(comm) {
  // header: name, description, members, grade
  const headerDiv = document.getElementById('communityHeader');
  headerDiv.innerHTML = '';
  const title = document.createElement('h1');
  title.className = 'text-2xl font-bold';
  title.textContent = comm.name;
  const desc = document.createElement('p');
  desc.className = 'text-gray-400 mb-2';
  desc.textContent = comm.description || '';
  const members = document.createElement('p');
  members.className = 'text-sm text-gray-500 mb-2';
  members.textContent = `${comm.members} membres`;
  const gradeInfo = document.createElement('p');
  gradeInfo.className = 'text-sm';
  gradeInfo.textContent = currentUser ? `Vous êtes ${currentUser.grade} (XP ${currentUser.xp})` : '';
  headerDiv.appendChild(title);
  headerDiv.appendChild(desc);
  headerDiv.appendChild(members);
  headerDiv.appendChild(gradeInfo);
  // hall of fame
  const hall = document.getElementById('hallOfFame');
  hall.innerHTML = '';
  if (comm.hallOfFame.length === 0) {
    hall.innerHTML = '<p class="text-gray-400">Aucune vidéo en tendance.</p>';
  } else {
    comm.hallOfFame.forEach((v) => {
      const div = createVideoItem(v, true);
      hall.appendChild(div);
    });
  }
  // garbage
  const garbage = document.getElementById('garbage');
  garbage.innerHTML = '';
  if (comm.garbage.length === 0) {
    garbage.innerHTML = '<p class="text-gray-400">Pas encore de vidéos.</p>';
  } else {
    comm.garbage.forEach((v) => {
      const div = createVideoItem(v, false);
      garbage.appendChild(div);
    });
  }
  // posts
  const postsList = document.getElementById('posts');
  postsList.innerHTML = '';
  if (comm.posts.length === 0) {
    postsList.innerHTML = '<p class="text-gray-400">Pas de messages pour l’instant.</p>';
  } else {
    comm.posts.forEach((p) => {
      const item = createPostItem(p);
      postsList.appendChild(item);
    });
  }
  // sub communities
  const sub = document.getElementById('subCommunities');
  sub.innerHTML = '';
  if (comm.subCommunities.length === 0) {
    sub.innerHTML = '<p class="text-gray-400">Aucune sous‑tribu.</p>';
  } else {
    comm.subCommunities.forEach((s) => {
      const card = document.createElement('div');
      card.className = 'bg-gray-800 rounded p-3 shadow';
      card.innerHTML = `
        <h3 class="font-semibold">${s.name}</h3>
        <p class="text-sm text-gray-400 mb-2">${s.description || ''}</p>
        <p class="text-xs text-gray-500 mb-2">${s.members} membres</p>
        <a href="/community.html?id=${s.id}" class="text-indigo-400 hover:underline">Entrer</a>
      `;
      sub.appendChild(card);
    });
  }

  // render polls
  renderPolls(comm.polls || []);
  // render admin actions for sages
  renderAdminActions();

  // update the user bar (XP bar, badges)
  renderUserBar();
  // compute and render weekly ranking
  renderWeeklyRanking(comm);
}

// Render list of polls
function renderPolls(polls) {
  const container = document.getElementById('polls');
  container.innerHTML = '';
  if (!polls || polls.length === 0) {
    container.innerHTML = '<p class="text-gray-400">Aucun vote en cours.</p>';
    return;
  }
  polls.forEach((poll) => {
    container.appendChild(createPollItem(poll));
  });
}

// Create a poll element
function createPollItem(poll) {
  const div = document.createElement('div');
  div.className = 'bg-gray-800 p-3 rounded shadow';
  let title;
  if (poll.type === 'delete_community') {
    title = 'Suppression de la tribu';
  } else if (poll.type === 'create_subcommunity') {
    title = `Création de la sous‑tribu “${poll.name}”`;
  } else {
    title = poll.type;
  }
  const header = document.createElement('p');
  header.className = 'font-semibold';
  header.textContent = title;
  div.appendChild(header);
  // counts
  const counts = document.createElement('p');
  counts.className = 'text-sm text-gray-400';
  counts.textContent = `${poll.yes_count} pour • ${poll.no_count} contre`;
  div.appendChild(counts);
  // vote buttons if open
  if (poll.status === 'open' && currentUser) {
    const btns = document.createElement('div');
    btns.className = 'mt-2 flex gap-2';
    const yesBtn = document.createElement('button');
    yesBtn.className = 'bg-green-600 hover:bg-green-700 px-3 py-1 rounded text-sm';
    yesBtn.textContent = 'Pour';
    yesBtn.addEventListener('click', () => {
      votePoll(poll.id, true);
    });
    const noBtn = document.createElement('button');
    noBtn.className = 'bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-sm';
    noBtn.textContent = 'Contre';
    noBtn.addEventListener('click', () => {
      votePoll(poll.id, false);
    });
    btns.appendChild(yesBtn);
    btns.appendChild(noBtn);
    div.appendChild(btns);
  }
  return div;
}

async function votePoll(pollId, voteVal) {
  try {
    await fetch(`/api/polls/${pollId}/votes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, vote: voteVal }),
    });
  } catch (e) {}
}

// Fetch grade advantages from the server and render them into the designated section.
async function renderGradeAdvantages() {
  try {
    const res = await fetch('/api/grade-advantages');
    const advantages = await res.json();
    const container = document.getElementById('gradeAdvantages');
    if (!container) return;
    container.innerHTML = '';
    Object.keys(advantages).forEach((gradeKey) => {
      const gradeTitle = gradeKey.charAt(0).toUpperCase() + gradeKey.slice(1);
      const wrapper = document.createElement('div');
      wrapper.className = 'bg-gray-800 p-3 rounded shadow';
      const titleEl = document.createElement('p');
      titleEl.className = 'font-semibold mb-1';
      titleEl.textContent = gradeTitle;
      wrapper.appendChild(titleEl);
      const list = document.createElement('ul');
      list.className = 'list-disc list-inside text-sm text-gray-300';
      advantages[gradeKey].forEach((adv) => {
        const li = document.createElement('li');
        li.textContent = adv;
        list.appendChild(li);
      });
      wrapper.appendChild(list);
      container.appendChild(wrapper);
    });
  } catch (e) {
    console.error('Erreur lors du chargement des avantages des grades', e);
  }
}

// Render admin actions (for Sages) to launch new polls
function renderAdminActions() {
  const adminDiv = document.getElementById('adminActions');
  adminDiv.innerHTML = '';
  // Only ambassadors or higher can launch moderation polls
  if (!currentUser) return;
  const grade = currentUser.grade.toLowerCase();
  if (!['ambassadeur', 'curateur', 'sage'].includes(grade)) return;
  // Button to launch deletion poll
  const delBtn = document.createElement('button');
  delBtn.className = 'bg-red-600 hover:bg-red-700 px-4 py-2 rounded mt-2 mr-2';
  delBtn.textContent = 'Lancer un vote pour supprimer la tribu';
  delBtn.addEventListener('click', async () => {
    if (!confirm('Créer un vote pour supprimer cette tribu ?')) return;
    await fetch(`/api/communities/${communityId}/polls`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, type: 'delete_community' }),
    });
  });
  adminDiv.appendChild(delBtn);
  // Button to launch create sub-community poll
  const createPollBtn = document.createElement('button');
  createPollBtn.className = 'bg-green-600 hover:bg-green-700 px-4 py-2 rounded mt-2';
  createPollBtn.textContent = 'Lancer un vote pour créer une sous‑tribu';
  createPollBtn.addEventListener('click', () => {
    const name = prompt('Nom de la nouvelle sous‑tribu :');
    if (!name) return;
    const description = prompt('Description :') || '';
    fetch(`/api/communities/${communityId}/polls`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, type: 'create_subcommunity', name, description }),
    });
  });
  adminDiv.appendChild(createPollBtn);
}

function createVideoItem(v, trending) {
  const div = document.createElement('div');
  div.className = 'bg-gray-800 p-3 rounded shadow flex flex-col';
  // Header
  const header = document.createElement('h4');
  header.className = 'font-semibold';
  header.textContent = v.title;
  div.appendChild(header);
  // Description
  const desc = document.createElement('p');
  desc.className = 'text-sm text-gray-400';
  desc.textContent = v.description || '';
  div.appendChild(desc);
  // Info line: uploader, views, likes, trending star
  const info = document.createElement('p');
  info.className = 'text-xs text-gray-500';
  let infoText = `par ${v.uploader} • ${v.views} vues`;
  if (typeof v.likes !== 'undefined') {
    infoText += ` • ${v.likes} likes`;
  }
  // Append reaction counts if available
  if (v.reactions) {
    const fire = v.reactions.fire || 0;
    const heart = v.reactions.heart || 0;
    const idea = v.reactions.idea || 0;
    const down = v.reactions.thumbs_down || 0;
    infoText += ` • 🔥 ${fire} ❤️ ${heart} 💡 ${idea} 👎 ${down}`;
  }
  if (v.is_trending) {
    infoText += ' • ⭐';
  }
  info.textContent = infoText;
  div.appendChild(info);
  // Actions: Watch, Like, Delete (if owner or sage)
  const actions = document.createElement('div');
  actions.className = 'mt-2 flex gap-2 flex-wrap';
  // Watch button
  const watchBtn = document.createElement('button');
  watchBtn.className = 'bg-indigo-600 hover:bg-indigo-700 px-3 py-1 rounded text-sm';
  watchBtn.textContent = 'Regarder';
  watchBtn.addEventListener('click', () => {
    window.open(v.file_path, '_blank');
    fetch(`/api/videos/${v.id}/view`, { method: 'POST' });
  });
  actions.appendChild(watchBtn);
  // Reaction buttons (fire, heart, idea, thumbs down)
  if (currentUser) {
    reactionTypes.forEach((rt) => {
      const rBtn = document.createElement('button');
      rBtn.className = 'px-2 py-1 rounded text-lg hover:scale-110 transition-transform';
      rBtn.textContent = rt.emoji;
      rBtn.title = `Réagir avec ${rt.type}`;
      rBtn.addEventListener('click', async () => {
        try {
          const resp = await fetch(`/api/videos/${v.id}/react`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: currentUser.username, reaction: rt.type }),
          });
          const data = await resp.json();
          if (data.error) {
            alert(data.error);
          } else {
            // update local counts if provided
            if (!v.reactions) v.reactions = {};
            v.reactions[rt.type] = data.count;
            // Show XP toast if the API returns xpGain
            if (typeof data.xpGain === 'number') {
              currentUser.xp += data.xpGain;
              showToast(`+${data.xpGain} XP`);
            }
            loadCommunity();
          }
        } catch (err) {
          console.error(err);
        }
      });
      actions.appendChild(rBtn);
    });
  }
  // Delete button: visible to uploader or sages
  if (currentUser && (currentUser.username === v.uploader || currentUser.grade.toLowerCase() === 'sage')) {
    const delBtn = document.createElement('button');
    delBtn.className = 'bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-sm';
    delBtn.textContent = 'Supprimer';
    delBtn.addEventListener('click', async () => {
      if (!confirm('Supprimer cette vidéo ?')) return;
      await fetch(`/api/videos/${v.id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: currentUser.username }),
      });
    });
    actions.appendChild(delBtn);
  }
  div.appendChild(actions);
  return div;
}

function createPostItem(p) {
  const div = document.createElement('div');
  const g = gradeMap[p.grade.toLowerCase()] || gradeMap.explorateur;
  // Add highlight ring if applicable
  div.className = `bg-gray-800 p-3 rounded shadow ${g.ring}`;
  const date = new Date(p.created_at);
  // Header line with avatar, username, grade and date
  const header = document.createElement('p');
  header.className = 'text-sm flex items-center';
  // Avatar: use custom avatar from user record if available
  header.appendChild(createAvatarSpan(p.grade, p.avatar));
  // Username
  const userSpan = document.createElement('span');
  userSpan.textContent = p.username;
  userSpan.className = 'font-semibold mr-1';
  header.appendChild(userSpan);
  // Grade text
  const gradeSpan = document.createElement('span');
  gradeSpan.textContent = `(${p.grade})`;
  gradeSpan.className = 'text-xs text-gray-400 mr-1';
  header.appendChild(gradeSpan);
  // Date
  const dateSpan = document.createElement('span');
  dateSpan.textContent = date.toLocaleString();
  dateSpan.className = 'text-xs text-gray-500';
  header.appendChild(document.createTextNode(' • '));
  header.appendChild(dateSpan);
  div.appendChild(header);
  // Content
  const contentPara = document.createElement('p');
  contentPara.className = 'mt-1 text-gray-300 whitespace-pre-wrap';
  // Highlight @mentions in the content by wrapping them in a span
  let htmlContent = p.content
    .replace(/\n/g, '<br>')
    .replace(/@([a-zA-Z0-9_]+)/g, '<span class="text-indigo-400">@$1</span>');
  contentPara.innerHTML = htmlContent;
  div.appendChild(contentPara);
  // Reaction counts line
  if (p.reactions) {
    const counts = document.createElement('p');
    counts.className = 'text-xs text-gray-500 mt-1';
    const fire = p.reactions.fire || 0;
    const heart = p.reactions.heart || 0;
    const idea = p.reactions.idea || 0;
    const down = p.reactions.thumbs_down || 0;
    counts.textContent = `🔥 ${fire}  ❤️ ${heart}  💡 ${idea}  👎 ${down}`;
    div.appendChild(counts);
  }
  // Reaction buttons
  if (currentUser) {
    const reactBar = document.createElement('div');
    reactBar.className = 'mt-1 flex gap-1';
    reactionTypes.forEach((rt) => {
      const btn = document.createElement('button');
      btn.className = 'px-2 py-1 rounded text-lg hover:scale-110 transition-transform';
      btn.textContent = rt.emoji;
      btn.title = `Réagir avec ${rt.type}`;
      btn.addEventListener('click', async () => {
        try {
          const resp = await fetch(`/api/posts/${p.id}/react`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: currentUser.username, reaction: rt.type }),
          });
          const data = await resp.json();
          if (!data.error) {
            if (!p.reactions) p.reactions = {};
            p.reactions[rt.type] = data.count;
            if (typeof data.xpGain === 'number') {
              currentUser.xp += data.xpGain;
              showToast(`+${data.xpGain} XP`);
            }
            loadCommunity();
          }
        } catch (err) {
          console.error(err);
        }
      });
      reactBar.appendChild(btn);
    });
    div.appendChild(reactBar);
  }
  // Replies container
  const repliesContainer = document.createElement('div');
  repliesContainer.className = 'ml-4 mt-2 space-y-2';
  // Render existing replies if available
  if (Array.isArray(p.replies) && p.replies.length > 0) {
    p.replies.forEach((rep) => {
      repliesContainer.appendChild(createPostItem(rep));
    });
  }
  div.appendChild(repliesContainer);
  // Reply form
  if (currentUser) {
    const replyToggle = document.createElement('button');
    replyToggle.className = 'mt-1 text-xs text-indigo-400 hover:underline';
    replyToggle.textContent = 'Répondre';
    div.appendChild(replyToggle);
    const replyForm = document.createElement('form');
    replyForm.className = 'mt-1 hidden';
    const replyInput = document.createElement('textarea');
    replyInput.className = 'w-full bg-gray-700 p-2 rounded text-sm';
    replyInput.rows = 2;
    replyInput.placeholder = 'Votre réponse…';
    const sendBtn = document.createElement('button');
    sendBtn.type = 'submit';
    sendBtn.textContent = 'Envoyer';
    sendBtn.className = 'mt-1 bg-indigo-600 hover:bg-indigo-700 px-3 py-1 rounded text-sm';
    replyForm.appendChild(replyInput);
    replyForm.appendChild(sendBtn);
    div.appendChild(replyForm);
    replyToggle.addEventListener('click', () => {
      replyForm.classList.toggle('hidden');
    });
    replyForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const text = replyInput.value.trim();
      if (!text) return;
      try {
        const resp = await fetch(`/api/posts/${p.id}/reply`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: currentUser.username, content: text }),
        });
        const data = await resp.json();
        if (!data.error) {
          replyInput.value = '';
          showToast('+2 XP');
          loadCommunity();
        }
      } catch (err) {
        console.error(err);
      }
    });
  }
  return div;
}

document.addEventListener('DOMContentLoaded', async () => {
  communityId = getParam('id');
  if (!communityId) {
    alert('Identifiant manquant');
    window.location = '/';
    return;
  }
  await initUser();
  // Render the user bar (avatar, XP, badges)
  renderUserBar();
  // update subForm visibility based on grade
  updateSubFormVisibility();
  socket = io();
  socket.emit('joinCommunityRoom', communityId);
  socket.on('post:new', (post) => {
    const postsList = document.getElementById('posts');
    // prepend new post
    postsList.prepend(createPostItem(post));
  });
  socket.on('video:new', (vid) => {
    // if trending (is_trending==1) may need to update Hall of Fame; else garbage
    if (vid.is_trending) {
      const hall = document.getElementById('hallOfFame');
      hall.prepend(createVideoItem(vid, true));
    } else {
      const garbage = document.getElementById('garbage');
      garbage.prepend(createVideoItem(vid, false));
    }
  });
  socket.on('video:update', (update) => {
    // re-fetch community details to reflect view count/trending changes
    loadCommunity();
  });
  // Poll events
  socket.on('poll:new', (poll) => {
    if (String(poll.community_id) === String(communityId)) {
      const container = document.getElementById('polls');
      // prepend new poll
      container.prepend(createPollItem(poll));
    }
  });
  socket.on('poll:update', (update) => {
    if (String(update.id)) {
      // For simplicity, reload community polls
      loadCommunity();
    }
  });
  socket.on('community:deleted', ({ id }) => {
    if (String(id) === String(communityId)) {
      alert('Cette tribu a été supprimée. Vous allez être redirigé.');
      window.location = '/';
    }
  });
  socket.on('community:new', (comm) => {
    // If a new sub-community is created under this community, reload list
    if (String(comm.parent_id) === String(communityId)) {
      loadCommunity();
    }
  });
  await loadCommunity();
  // Fetch and render grade advantages section
  renderGradeAdvantages();
  // handle post form
  document.getElementById('postForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const content = document.getElementById('postContent').value.trim();
    if (!content) return;
    await fetch(`/api/communities/${communityId}/posts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: currentUser.username, content }),
    });
    document.getElementById('postContent').value = '';
  });
  // handle sub community form
  document.getElementById('subForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('subName').value.trim();
    const description = document.getElementById('subDesc').value.trim();
    if (!name) return;
    await fetch('/api/communities', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description, parentId: communityId, username: currentUser.username }),
    });
    document.getElementById('subName').value = '';
    document.getElementById('subDesc').value = '';
    loadCommunity();
  });
  // handle video upload form
  document.getElementById('videoForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('videoTitle').value.trim();
    const description = document.getElementById('videoDesc').value.trim();
    const fileInput = document.getElementById('videoFile');
    if (!title || !fileInput.files[0]) return;
    const fd = new FormData();
    fd.append('video', fileInput.files[0]);
    fd.append('title', title);
    fd.append('description', description);
    fd.append('username', currentUser.username);
    const res = await fetch(`/api/communities/${communityId}/videos`, {
      method: 'POST',
      body: fd,
    });
    if (!res.ok) {
      const data = await res.json();
      alert(data.error || 'Erreur lors de l’upload');
    }
    document.getElementById('videoTitle').value = '';
    document.getElementById('videoDesc').value = '';
    document.getElementById('videoFile').value = '';
    // new video will be added via socket event
  });
});